const ROLES = {
  ADMIN: "ADMIN",
  FLEET_MANAGER: "FLEETMANAGER",
};

module.exports = ROLES;
